function myFunction(element) {
    const thisDropdown = element.previousElementSibling;
    thisDropdown.classList.toggle("show");

    if (element.innerHTML === "SHOW MORE") {
        element.innerHTML = "SHOW LESS"
    } else {
        element.innerHTML = "SHOW MORE"
    }
}

var myIndex2 = 0;
carousel2();

function carousel2() {
    var j;
    var k = document.getElementsByClassName("mySlides2");
    for (j = 0; j < k.length; j++) {
        k[j].style.display = "none";
    }
    myIndex2++;
    if (myIndex2 > k.length) { myIndex2 = 1 }
    k[myIndex2 - 1].style.display = "block";
    setTimeout(carousel2, 5000); // Change image every 2 seconds
}

let slideIndex = 1;
showSlides2(slideIndex);

function plusSlides(n) {
    showSlides2(slideIndex += n);
}

function currentSlide(n) {
    showSlides2(slideIndex = n);
}

function showSlides2(n) {
    let i;
    let slides = document.getElementsByClassName("mySlides2");
    let dots = document.getElementsByClassName("dot");
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
}
var myIndex3 = 0;
carousel3();
function carousel3() {
    var i;
    var x = document.getElementsByClassName("news_content");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    myIndex3++;
    if (myIndex3 > x.length) { myIndex3 = 1 }
    x[myIndex3 - 1].style.display = "block";
    setTimeout(carousel3, 7000); // Change image every 2 seconds
}
let slideIndex2 = 1;
showSlides(slideIndex2);

function plusSlides2(n) {
    showSlides(slideIndex2 += n);
}

function currentSlide2(n) {
    showSlides(slideIndex2 = n);
}

function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("news_content");
    if (n > slides.length) { slideIndex2 = 1 }
    if (n < 1) { slideIndex2 = slides.length }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slides[slideIndex2 - 1].style.display = "block";
}
var myIndex4 = 0;
carousel4();

function carousel4() {
    var m;
    var n = document.getElementsByClassName("mySlides");
    for (m = 0; m < n.length; m++) {
        n[m].style.display = "none";
    }
    myIndex4++;
    if (myIndex4 > n.length) { myIndex4 = 1 }
    n[myIndex4 - 1].style.display = "block";
    setTimeout(carousel4, 3000);
}
let slideIndex3 = 1;
showSlides3(slideIndex3);

function plusSlides3(n) {
    showSlides3(slideIndex3 += n);
}

function currentSlide3(n) {
    showSlides3(slideIndex3 = n);
}

function showSlides3(n) {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    if (n > slides.length) { slideIndex3 = 1 }
    if (n < 1) { slideIndex3 = slides.length }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    slides[slideIndex3 - 1].style.display = "block";
}

function myFunction2() {
    var x = document.getElementById("navmenu");
    if (x.className === "menu") {
        x.className += " responsive";
        document.getElementById('dropdown_content_responsive').classList.remove('dropdown_content');
        document.getElementById('dropdown_content_responsive').classList.add('dropdown_content_responsive');
        document.getElementById('dropdown_content_responsive2').classList.remove('dropdown_content2');
        document.getElementById('dropdown_content_responsive2').classList.add('dropdown_content_responsive2');
    }
    else {
        x.className = "menu";
        document.getElementById('dropdown_content_responsive').classList.remove('dropdown_content_responsive');
        document.getElementById('dropdown_content_responsive2').classList.remove('dropdown_content_responsive2');
    }

    // var y = document.getElementsByClassName("dropdown_content");
    // if (y.className === "dropdown_content") {
    //     y.className += "dropdown_content_responsive";
    // }
    // else {
    //     y.className = "dropdown_content";
    // }
}

function initMap() {
    const gjakova = { lat: 42.382165, lng: 20.430794 };
    const map = new google.maps.Map(document.getElementById("map"), {
        zoom: 14,
        center: gjakova,
    });
    const marker = new google.maps.Marker({
        position: gjakova,
        map: map,
    });
}
window.initMap = initMap;
var slider = new KeenSlider("#my-keen-slider", {
    loop: true,
    mode: "free-snap",
    slides: {
        perView: 3,
        spacing: 15,
    }, breakpoints: {
        "(max-width: 650px)": {
            slides: { perView: 1, spacing: 5 },
        },
        "(min-width: 650px)": {
            slides: { perView: 2, spacing: 5 },
        },
        "(min-width: 1000px)": {
            slides: { perView: 3, spacing: 10 },
        },
    }
})


// AIzaSyBoyHFOPbIvZR4uSHXQSQzFVe0rLMlFp3Q